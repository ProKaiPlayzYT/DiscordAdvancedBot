
const Color = "RANDOM";
const Discord = require("discord.js");

module.exports = {
  name: "vote",
  aliases: ["upvote"],
  category: "info",
  description: "Vote link",
  usage: "Vote",
  run: async (client, message, args) => {
    
   

    const Embed = new Discord.MessageEmbed()
    .setColor(Color)
    .setTitle("Vote Bot")
    .setDescription("You can vote us in **discordbotlist** \n **_discordbotlist_** [Click Here](https://discordbotlist.com/bots/prokais-mod-bot)")
    .setImage(``)
    .setTimestamp();

    return message.channel.send(Embed);
  }
};
