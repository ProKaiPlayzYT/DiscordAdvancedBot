const Discord = require ('discord.js')
const { MessageEmbed } = require('discord.js')

module.exports = {
name: "invite",
aliases: ["inv"],
category: "info",
usage: "=invite",
description: "Invite the bot to your server..",
run: async(client, message, args) => {
  
 await message.delete()
  
  let embed = new MessageEmbed()
.setTitle(`StrikerBot™`)
  .setDescription(`
  __WOW!__ You can add me and also join my support server by links below \n **Invite:** [Click Here](https://discord.com/api/oauth2/authorize?client_id=857234196132921354&permissions=4294967287&scope=bot)\n **Support Server:** [Click Here](https://discord.gg/M9padMsaER) \n **Web-Dashboard:** [Click Here](https://discord-bot-webiste.prokaiplayz.repl.co/index.html) \n  `)
  .setColor("RANDOM")
  .setThumbnail(message.guild.iconURL())
.setFooter(` ${message.guild} `)
.setTimestamp()
  message.channel.send(embed)
}
}