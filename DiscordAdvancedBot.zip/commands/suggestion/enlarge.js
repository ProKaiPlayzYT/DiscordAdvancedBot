module.exports = {
    name: "enlarge",
    description: "make emoji in big size",
category: "utility",
}