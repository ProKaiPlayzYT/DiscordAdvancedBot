export default interface Position {
    x: number;
    y: number;
}